export interface IPlanta {
    titulo: string;
    texto: string;
    imagen: string;
    tipoDeHoja: string;
    tipoDeLuzNecesaria: string;
    fechaPublicacion: string;
}
